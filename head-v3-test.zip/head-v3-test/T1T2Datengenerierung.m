close all; 
clear;
% Parameter
N=224;                 %Gr��e des Bildes
z=0;                   %Variable f�r Bildbenennung

%RelaxationszeiTRn T1
M0=1;
TR_1=0.400;            % TR kurz 300-600ms
TE_1=0.001;            % sehr kurzes TE <20ms damit e^(TE/T2) gg 1 geht
T1_scalp =0.324;
T1_csf=4.2;
T1_GM=0.857;
T1_WM=0.583;
%RelaxationszeiTRn T2
TR_2 = 5;              % Langes TR damit Mz f�r alle gleich TR>2000ms
TE_2=0.125;            % TE 75-125ms l�nger f�r gr��ere Unterschiede
T2_scalp=0.070;
T2_csf=1.99;
T2_GM=0.1;
T2_WM=0.08;
w0=180;

for i=1:40              % Anzahl der Durchl�ufe (7 Bilder T1 u. 7Bilder T2 pro Durchlauf) 
%Anatomie Variationen -->random Gr��e Ellipsen nicht ver�ndert nur Position
%Zufallszahl = (rand(1)*(start-ende)+ende);
y_GM = (rand(1)*(-0.04-0.04)+0.04);
x_csf = (rand(1)*(0.1-0.35)+0.35);
y_csf = (rand(1)*(-0.3-0.04)+0.04);
y_WM = (rand(1)*(0.3-0.5)+0.5); 
phi_csf = (rand(1)*(0.1-45)+45); 

%Ver�nderung der TE und TR zeiten 
TR_1 = (rand(1)*(0.300-0.600)+0.600);
TE_1 = (rand(1)*(0.001-0.02)+0.020);
TE_2 = (rand(1)*(0.075-0.125)+0.125);

% InTRnsit�t der jeweiligen Elipse nach T1-Relaxation Blochsche-GL
% Mz=M0*(1-exp(-TR/T1)*exp(-TE/T2)
scalpT1 = (M0*(1-exp(-TR_1/T1_scalp))*exp(-TE_1/T2_scalp));        
GMT1 = (M0*(1-exp(-TR_1/T1_GM))*exp(-TE_1/T2_GM));        
CSFT1 =( M0*(1-exp(-TR_1/T1_csf))*exp(-TE_1/T2_csf));        
WMT1 = (M0*(1-exp(-TR_1/T1_WM))*exp(-TE_1/T2_WM));         

% InTRnsit�t der jeweiligen Elipse nach T2-Relaxation Blochsche-GL
% Mxy=-M0*exp(-t/T2)*sin(w0*t)
scalpT2 = M0*(1-exp(-TR_2/T1_scalp))*exp(-TE_2/T2_scalp);               
GMT2 = M0*(1-exp(-TR_2/T1_GM))*exp(-TE_2/T2_GM);            
CSFT2 = M0*(1-exp(-TR_2/T1_csf))*exp(-TE_2/T2_csf);            
WMT2 = M0*(1-exp(-TR_2/T1_WM))*exp(-TE_2/T2_WM);                


%Matrix f�r Shepp Logan mit InTRnsit�TRn f�r T1
%         A         a        b     x0    y0    phi
%        --------------------------------------------
T1    = [ scalpT1   .69   .92      0     0     0          % scalp
          GMT1      .6624 .8740    0    y_GM   0          % GM
          CSFT1     .1100 .3100  x_csf  y_csf -phi_csf    % CSF
          CSFT1     .1600 .4100 -x_csf  y_csf  phi_csf    % CSF
          WMT1      .2100 .2500    0    y_WM    0];       % WM
         
 
%Matrix f�r Shepp Logan mit InTRnsit�TRn f�r T2 
%         A           a     b     x0    y0     phi
%        --------------------------------------------
T2    = [ scalpT2   .69    .92     0       0     0          % scalp
          GMT2      .6624 .8740    0      y_GM   0          % GM
          CSFT2     .1100 .3100   x_csf   y_csf -phi_csf    % CSF
          CSFT2     .1600 .4100  -x_csf   y_csf  phi_csf    % CSF
          WMT2      .2100 .2500    0      y_WM   0];        % WM

z= z+1;
figure(1);
PhantomT1 = phantom1(T1,N);
%PhantomT1= PhantomT1*.255;
imshow(PhantomT1)
imwrite(PhantomT1,sprintf('T1_%d.jpg',z),"jpg") 

figure(2);
PhantomT2= phantom1(T2,N);
%PhantomT2 = PhantomT2*.255;
imshow(PhantomT2)
imwrite(PhantomT2,sprintf('T2_%d.jpg',z),"jpg") 

%Rotation
z= z+1;
tform = randomAffine2d('Rotation',[-45 45]); 
outputView = affineOutputView(size(PhantomT1),tform);
imAugmenTRdRot = imwarp(PhantomT1,tform,'OutputView',outputView);  
imwrite(imAugmenTRdRot,sprintf('T1_%d.jpg',z),"jpg") 

tform = randomAffine2d('Rotation',[-45 45]); 
outputView = affineOutputView(size(PhantomT2),tform);
imAugmenTRdRot = imwarp(PhantomT2,tform,'OutputView',outputView);  
imwrite(imAugmenTRdRot,sprintf('T2_%d.jpg',z),"jpg") 

%Translation
z= z+1;
tform = randomAffine2d('XTranslation',[-5 5],'YTranslation',[-5 5]);
outputView = affineOutputView(size(PhantomT1),tform);
imAugmenTRdTrans = imwarp(PhantomT1,tform,'OutputView',outputView);
imwrite(imAugmenTRdTrans,sprintf('T1_%d.jpg',z),"jpg") 

tform = randomAffine2d('XTranslation',[-5 5],'YTranslation',[-5 5]);
outputView = affineOutputView(size(PhantomT2),tform);
imAugmenTRdTrans = imwarp(PhantomT2,tform,'OutputView',outputView);
imwrite(imAugmenTRdTrans,sprintf('T2_%d.jpg',z),"jpg") 

%Scale
z= z+1;
tform = randomAffine2d('Scale',[0.5,1.2]);
outputView = affineOutputView(size(PhantomT1),tform);
imAugmenTRdScale = imwarp(PhantomT1,tform,'OutputView',outputView);
imwrite(imAugmenTRdScale,sprintf('T1_%d.jpg',z),"jpg") 

tform = randomAffine2d('Scale',[0.5,1.2]);
outputView = affineOutputView(size(PhantomT2),tform);
imAugmenTRdScale = imwarp(PhantomT2,tform,'OutputView',outputView);
imwrite(imAugmenTRdScale,sprintf('T2_%d.jpg',z),"jpg") 

%Reflection
z= z+1;
tform = randomAffine2d('XReflection',true,'YReflection',true);
outputView = affineOutputView(size(PhantomT1),tform);
imAugmenTRdReflection = imwarp(PhantomT1,tform,'OutputView',outputView);
imwrite(imAugmenTRdReflection,sprintf('T1_%d.jpg',z),"jpg") 

tform = randomAffine2d('XReflection',true,'YReflection',true);
outputView = affineOutputView(size(PhantomT2),tform);
imAugmenTRdReflection = imwarp(PhantomT2,tform,'OutputView',outputView);
imwrite(imAugmenTRdReflection,sprintf('T2_%d.jpg',z),"jpg") 

%Shear
z= z+1;
tform = randomAffine2d('XShear',[-10 10]); 
outputView = affineOutputView(size(PhantomT1),tform); 
imAugmenTRdShear = imwarp(PhantomT1,tform,'OutputView',outputView);
imwrite(imAugmenTRdShear,sprintf('T1_%d.jpg',z),"jpg") 

tform = randomAffine2d('XShear',[-10 10]); 
outputView = affineOutputView(size(PhantomT2),tform); 
imAugmenTRdShear = imwarp(PhantomT2,tform,'OutputView',outputView);
imwrite(imAugmenTRdShear,sprintf('T2_%d.jpg',z),"jpg") 

%Rauschen
z= z+1;
imAugmenTRdNoise = imnoise(PhantomT1,'gaussian',0.01);
imwrite(imAugmenTRdNoise,sprintf('T1_%d.jpg',z),"jpg")

imAugmenTRdNoise = imnoise(PhantomT2,'gaussian',0.01);
imwrite(imAugmenTRdNoise,sprintf('T2_%d.jpg',z),"jpg")
end